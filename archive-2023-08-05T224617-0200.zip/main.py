from classik import MultiClient
import asyncio
from telethon import events, errors
import datetime
import time
import os
import asyncio
import concurrent.futures
from twocaptcha import TwoCaptcha
import random

API_KEY = '111093d6d3b1ccf4c11b2860db33c2b3'
solver = TwoCaptcha(API_KEY)
api_id = 22909922
api_hash = 'f7e45cc2ac8717f3bb3bc429a47b13e7'

async def captchaSolver(image):
    loop = asyncio.get_running_loop()
    with concurrent.future.ThreadPoolExecutor() as pool:
        result = await loop.run_in_executor(pool, lambda: TwoCaptcha(API_KEY).normal(image))
        return result

current_time = datetime.datetime.now().time()
now = current_time.strftime("%H:%M:%S")
sessio = os.listdir('sessions')
client = MultiClient(api_id=api_id, api_hash=api_hash, sessions=sessio)


spam = ['Жаркие малолетки и голые школьницы, лишение дественности пальчиками, секс между маленькими тут - smallgirls_videosbot']

@client.on(events.NewMessage)
async def listener(event):
    try:
        if 'Собеседник найден ' in event.raw_text:
            current_time = datetime.datetime.now().time()
            now = current_time.strftime("%H:%M:%S")
            print(f'[LOG] Нашел собеседника',str(now))
            await event.client.send_message('AnonRuBot', random.choice(spam))
            print('[LOG] Отправляем ', random.choice(spam), str(now))
            print('[LOG] Перехожу к следующему', str(now))
            await event.client.send_message('AnonRuBot', '/next')
        if 'Собеседник закончил с вами связь '  in event.raw_text:
            current_time = datetime.datetime.now().time()
            now = current_time.strftime("%H:%M:%S")
            print('[LOG] Собеседник закончил связь, через 3 секунды начну поиск', str(now))
            await event.client.send_message('AnonRuBot', '/search')
        if 'У вас ограничение на количество чатов в сутки.' in event.raw_text:
            current_time = datetime.datetime.now().time()
            now = current_time.strftime("%H:%M:%S")
            print('[LOG] У вас ограничение на количество чатов в сутки.', str(now))
        if 'Приносим наши извинения' in event.raw_text:
            current_time = datetime.datetime.now().time()
            now = current_time.strftime("%H:%M:%S")
            print('[LOG] Аккаунт получил бан', str(now))
        if 'Введите ваш возраст' in event.raw_text:
            current_time = datetime.datetime.now().time()
            now = current_time.strftime("%H:%M:%S")
            await event.client.send_message('AnonRuBot', '10')
        if 'У вас уже есть собеседник' in event.raw_text:
            await event.client.send_message('AnonRuBot', '/next')
        if 'Чтобы подтвердить, что вы не бот, введите код с картинки' in event.raw_text:
            print('[ = CAPTCHA = ] Увидел капчу')
            capcha = await event.client.download_media(event.photo, f'captha')
            captcha = os.listdir(f'captha')
            result_photo = ''.join(captcha[-1])
            print('[ ? CAPTCHA ? ] Какой то человек пишет за тебя капчу ёк макарек')
            id = solver.send(file=f'captha/{result_photo}')
            time.sleep(15)
            code = solver.get_result(id)
            print(f'[ + CAPTCHA = ] CODE: {code}')
            await event.client.send_message('AnonRuBot', code)
        if 'Правильно!' in event.raw_text:
            print('[ + CAPTCHA + ] Капча решена')
        if 'Привет! Это создатели Анонимного чата. ' in event.raw_text:
            await event.client(JoinChannelRequest('anonimruchannel'))
            await event.client.send_message('AnonRuBot', '/search')
        if 'Неправильный код, попробуйте еще, либо пересоздайте капчу' in event.raw_text:
            await event.client.send_message('AnonRuBot', '/restartcaptcha')
    except errors.YouBlockedUserError:
        print('BLOCK USER')
    except errors.SessionRevokedError:
        print('SessionRevokedError')
    except errors.FloodWaitError:
        print('flood')
for c in client:
    print(c.session_id)

# run all the clients

loop = asyncio.get_event_loop()
client.run_all_clients(loop=loop)
